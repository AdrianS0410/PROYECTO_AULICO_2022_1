package com.example.afinal.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.afinal.R;
import com.example.afinal.model.Usuario;
import com.google.android.material.textfield.TextInputEditText;

public class UserRegister extends AppCompatActivity {
    //Atributos
    TextInputEditText nombre;
    TextInputEditText correo;
    TextInputEditText clave;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);
        //Costeamos los objetos con la vista
        this.nombre = findViewById(R.id.TxtNombreCrearUsuario);
        this.correo = findViewById(R.id.TxtCorreoCrearUsuario);
        this.clave = findViewById(R.id.TxtClaveCrearUsuario);

    }

    public void OnClick(View view) {
        //Definir condiciones
        if (view.getId() == R.id.BtnCrearUsuario) {
            //Instancio objeto tipo usuario
            //Instancio objeto tipo usuario
            Usuario object = new Usuario();
            //Inicializar datos de usuario
            object.getNombre(nombre.getText().toString());
            object.setCorreo(correo.getText().toString());
            object.setCorreo(clave.getText().toString());
            //condidion para evaluar la respuesta del modelo
            if (object.crear(this) == true) {
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "Usuario registrado correctamente", Toast.LENGTH_SHORT);
                toast1.show();
                //finalizo el registro
                Intent viewLogin = new Intent(UserRegister.this, Login.class);
                startActivity(viewLogin);
                finish();
            } else {
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "No se a creado el usuario, intente nuevamente", Toast.LENGTH_SHORT);
                toast1.show();

            }
        }
    }
}