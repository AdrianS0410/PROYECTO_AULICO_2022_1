package com.example.afinal.controller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.afinal.R;
import com.example.afinal.model.Usuario;
import com.google.android.material.textfield.TextInputEditText;

public class Login extends AppCompatActivity {
    //Atributos
    TextInputEditText correo;
    TextInputEditText clave;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //Costeamos los objetos con la vista
        this.correo = findViewById(R.id.TxtUsuarioLogin);
        this.clave = findViewById(R.id.TxtClaveLogin);
    }
    public void onClick(View view) {
        //Definir condiciones
        if (view.getId() == R.id.BtnIniciarLogin) {
            //Instancio objeto tipo usuario
            Usuario object = new Usuario();
            //Inicializar datos de usuario
            object.setCorreo(correo.getText().toString());
            object.setCorreo(clave.getText().toString());
            //condifion para evaluar la respuesta del modelo
            if (object.login(this) == true) {
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "Las credenciales son correctas", Toast.LENGTH_SHORT);
                toast1.show();
                //finalizo el registro
                Intent viewLogin = new Intent(Login.this, Home.class);
                startActivity(viewLogin);
                finish();
            } else {
                Toast toast1 = Toast.makeText(getApplicationContext(),
                        "La credenciales son Incorrectas, por favor cree una cuenta.", Toast.LENGTH_SHORT);
                toast1.show();
            }
        }else if (view.getId() == R.id.BtnCrearCuentaLogin){
            Intent viewRegister = new Intent(Login.this, UserRegister.class);
            startActivity(viewRegister);

        }
    }


}